#ifndef __SHA1_H
#define __SHA1_H

#include <gcrypt.h>

char *sha1(char *);
#ifdef __cplusplus

#endif
#endif