OneVote - Jonah, Matt, Ankit, Willy
=======

To compile and run, type "make run" to run the peer code for mining.