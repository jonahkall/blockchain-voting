#include "server.hpp"
#include "client.hpp"

int main () {
	return 0;
}
